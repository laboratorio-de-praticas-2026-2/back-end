export class Contato {}
